"""
Central configuration for all Azure services.
Copy .env.example to .env and fill in your real values.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).parent / ".env")

# ── Azure OpenAI (LLM / Agent) ──────────────────────────────────────────────
AZURE_OPENAI_ENDPOINT    = os.getenv("AZURE_OPENAI_ENDPOINT",    "https://<your-resource>.openai.azure.com/")
AZURE_OPENAI_API_KEY     = os.getenv("AZURE_OPENAI_API_KEY",     "<your-key>")
AZURE_OPENAI_API_VERSION = "2024-05-01-preview"
AZURE_OPENAI_DEPLOYMENT  = os.getenv("AZURE_OPENAI_DEPLOYMENT",  "gpt-4o")

# ── Azure AI Search (RAG) ────────────────────────────────────────────────────
AZURE_SEARCH_ENDPOINT    = os.getenv("AZURE_SEARCH_ENDPOINT",    "https://<your-search>.search.windows.net")
AZURE_SEARCH_KEY         = os.getenv("AZURE_SEARCH_KEY",         "<your-key>")
AZURE_SEARCH_INDEX       = "fraud-policy-index"

# ── Azure OpenAI Embeddings ──────────────────────────────────────────────────
AZURE_EMBED_DEPLOYMENT   = os.getenv("AZURE_EMBED_DEPLOYMENT",   "text-embedding-3-small")
AZURE_EMBED_ENDPOINT     = os.getenv("AZURE_EMBED_ENDPOINT",     AZURE_OPENAI_ENDPOINT)
AZURE_EMBED_API_VERSION  = os.getenv("AZURE_EMBED_API_VERSION",  AZURE_OPENAI_API_VERSION)
EMBED_DIMENSIONS         = 1536

# ── Azure ML AutoML Endpoint (Fraud Prediction) ──────────────────────────────
# After deploying your AutoML best model, copy the endpoint URL and key here.
# Format: https://<endpoint-name>.<region>.inference.ml.azure.com/score
AZURE_ML_ENDPOINT_URL    = os.getenv("AZURE_ML_ENDPOINT_URL",    "https://<endpoint>.inference.ml.azure.com/score")
AZURE_ML_ENDPOINT_KEY    = os.getenv("AZURE_ML_ENDPOINT_KEY",    "<your-key>")

# AutoML endpoints expect a different request format than custom score.py.
# Set to True once your AutoML endpoint is deployed.
USE_AUTOML_ENDPOINT      = os.getenv("USE_AUTOML_ENDPOINT", "true").lower() == "true"

# ── Azure ML Workspace (for automl_train_and_deploy.py) ──────────────────────
AZURE_SUBSCRIPTION_ID    = os.getenv("AZURE_SUBSCRIPTION_ID",    "<your-subscription-id>")
AZURE_RESOURCE_GROUP     = os.getenv("AZURE_RESOURCE_GROUP",     "<your-resource-group>")
AZURE_ML_WORKSPACE       = os.getenv("AZURE_ML_WORKSPACE",       "<your-workspace-name>")
AZURE_ML_COMPUTE         = os.getenv("AZURE_ML_COMPUTE",         "automl-compute")

# ── RAG retrieval settings ───────────────────────────────────────────────────
TOP_K_RESULTS  = 3
CHUNK_SIZE     = 512    # words per chunk
CHUNK_OVERLAP  = 64

# ── Fraud risk thresholds ────────────────────────────────────────────────────
HIGH_RISK_THRESHOLD  = 0.70   # call retrieve_policy when ML score >= this
COMPOSITE_RISK_HIGH  = 7.0    # out of 10 — triggers ML + RAG path
