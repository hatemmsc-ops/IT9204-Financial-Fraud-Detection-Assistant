"""
Part E – System Integration

End-to-end integration script. Runs all three example queries from the Topic
Approval Form, prints full outputs, and saves a JSON results log.

Usage:
    python main.py                    # run all demo queries
    python main.py --query "..."      # run a custom query
    python main.py --ingest           # re-ingest RAG documents first
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime

# Add sibling directories to path
BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE / "C - Agent System"))
sys.path.insert(0, str(BASE / "D - Decision and Reasoning Layer"))
sys.path.insert(0, str(BASE / "A - Data and Knowledge Layer"))

from agent import answer_query
from decision_logic import classify_query, DECISION_DIAGRAM

RESULTS_DIR = BASE / "F - Evaluation and Analysis"
RESULTS_DIR.mkdir(exist_ok=True)

# ── Demo queries from Topic Approval Form ─────────────────────────────────────

DEMO_QUERIES = [
    {
        "id": "Q1",
        "path": "A (Transaction)",
        "query": (
            "A transaction of $4,500 was made from a new device at 2:30 AM. "
            "Is this likely fraud?"
        ),
    },
    {
        "id": "Q2",
        "path": "B (Policy)",
        "query": (
            "What is the bank's policy when a high-risk transaction is detected "
            "on a corporate account?"
        ),
    },
    {
        "id": "Q3",
        "path": "C (Pattern)",
        "query": (
            "Customer Ahmed made 14 transactions in 20 minutes totalling $6,200. "
            "What does the risk assessment say and what action should be taken?"
        ),
    },
]


# ── Runner ────────────────────────────────────────────────────────────────────

def run_query(query_text: str, label: str = "") -> dict:
    """Run one query through the full agent pipeline and return structured result."""
    print(f"\n{'='*65}")
    print(f"  {label}")
    print(f"{'='*65}")
    print(f"Query: {query_text}\n")

    # Step 1: deterministic routing preview
    routing = classify_query(query_text)
    print(f"[Router] Path {routing.path.value} — {routing.path.name}")
    print(f"[Router] {routing.reason}")
    print()

    # Step 2: agent execution (LLM + tools)
    result = answer_query(query_text)

    print("\n── Agent Response ──────────────────────────────────────")
    print(result["response"])
    print()
    if result["tools_called"]:
        print(f"[Tools used: {', '.join(t['tool'] for t in result['tools_called'])}]")

    return {
        "label":        label,
        "query":        query_text,
        "routing_path": routing.path.name,
        "routing_reason": routing.reason,
        "tools_called": [t["tool"] for t in result["tools_called"]],
        "response":     result["response"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--query",  type=str, help="Run a custom query")
    parser.add_argument("--ingest", action="store_true", help="Re-ingest RAG docs before running")
    args = parser.parse_args()

    print("\n" + "="*65)
    print("  Financial Fraud Detection and Advisory Assistant")
    print("  IT9204 Individual Project | Hatem Isa (202508993)")
    print("="*65)
    print(DECISION_DIAGRAM)

    # Optionally re-ingest documents
    if args.ingest:
        from rag_pipeline import ingest_documents
        docs_folder = str(BASE / "A - Data and Knowledge Layer" / "RAG Documents")
        print(f"Ingesting documents from: {docs_folder}")
        ingest_documents(docs_folder)

    results = []

    if args.query:
        results.append(run_query(args.query, label="Custom Query"))
    else:
        for demo in DEMO_QUERIES:
            results.append(run_query(demo["query"], label=f"{demo['id']} — {demo['path']}"))

    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = RESULTS_DIR / f"integration_run_{timestamp}.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n[Results saved to: {out_path}]")


if __name__ == "__main__":
    main()
