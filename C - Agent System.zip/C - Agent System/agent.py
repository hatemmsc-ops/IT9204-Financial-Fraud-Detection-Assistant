"""
Part C – Agent System  |  Part D – Decision & Reasoning Layer

Financial Fraud Detection and Advisory Assistant
Azure OpenAI agent with function calling (tool use).

The agent:
  1. Classifies the incoming query (transaction-specific / policy-only / pattern-based / ambiguous)
  2. Decides which tools to invoke — the Decision & Reasoning Layer
  3. Executes tools, potentially in sequence (multi-step reasoning)
  4. Synthesises results into a grounded, explainable response

Run interactively:
    python agent.py
"""

import json
import sys
from pathlib import Path
from typing import Generator

from openai import AzureOpenAI

sys.path.insert(0, str(Path(__file__).parent.parent / "E - System Integration"))
from config import (
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION, AZURE_OPENAI_DEPLOYMENT,
    HIGH_RISK_THRESHOLD, COMPOSITE_RISK_HIGH,
)
from tools import TOOL_SCHEMAS, dispatch_tool


# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = f"""You are a Financial Fraud Detection and Advisory Assistant deployed by a bank.
Your users are fraud analysts and bank risk officers.

You have access to three tools:
1. predict_fraud_risk     — calls the ML model to score a specific transaction
2. retrieve_policy        — searches the compliance/fraud policy knowledge base
3. calculate_risk_score   — computes a composite risk score from transaction metadata

## Decision Rules (CRITICAL — follow exactly):

**Path A – Specific Transaction Query**
Trigger: User provides transaction details (amount, time, device, features).
Action:
  1. Call predict_fraud_risk with available features.
  2. If fraud_probability >= {HIGH_RISK_THRESHOLD}, ALSO call retrieve_policy
     with a query about the appropriate escalation/response procedure.
  3. Combine both outputs in your response.

**Path B – Policy/Procedure Query**
Trigger: User asks "what should we do", "what is the policy", "what are the steps".
Action: Call retrieve_policy only. Do NOT call the ML model.

**Path C – Transaction Pattern / Velocity Query**
Trigger: User describes multiple transactions, frequency, time windows, cumulative amounts.
Action:
  1. Call calculate_risk_score with the pattern details.
  2. If composite_score >= {COMPOSITE_RISK_HIGH}, ALSO call predict_fraud_risk
     (use 0.0 for unknown PCA features, use the described amount and time).
  3. If risk is high or critical, ALSO call retrieve_policy for escalation steps.

**Path D – Ambiguous Query**
Trigger: Query does not clearly fit A, B, or C.
Action: Reason about what information is most useful, then call the most relevant tool(s).

## Response Rules:
- Never fabricate policy rules. All recommendations must come from retrieved documents.
- Always cite the source document when quoting policy (e.g., "[bank_fraud_response_procedures]").
- Always state the fraud probability and risk level clearly when ML is used.
- Always state the composite score when calculate_risk_score is used.
- Be concise and professional. Use structured formatting (numbered steps, bold headings).
- If a Suspicious Activity Report (SAR) may be needed, explicitly flag this.
- Remind the analyst that the AI provides decision support only — the human analyst
  is responsible for the final action.
"""


# ── Client ────────────────────────────────────────────────────────────────────

client = AzureOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
)


# ── Agent loop ────────────────────────────────────────────────────────────────

def run_agent(user_query: str, conversation_history: list[dict] | None = None) -> dict:
    """
    Run one turn of the agent.
    Returns a dict with: response (str), tools_called (list), messages (list).
    """
    messages = (conversation_history or []) + [
        {"role": "user", "content": user_query}
    ]
    if not conversation_history:
        messages.insert(0, {"role": "system", "content": SYSTEM_PROMPT})

    tools_called = []

    # Agentic loop: keep calling the LLM until it produces a final text response
    while True:
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=messages,
            tools=TOOL_SCHEMAS,
            tool_choice="auto",
            temperature=0.1,    # low temperature for consistent, factual responses
            max_tokens=2048,
        )

        message = response.choices[0].message
        messages.append(message.model_dump(exclude_unset=True))

        # If no tool calls, we have the final answer
        if not message.tool_calls:
            return {
                "response":    message.content,
                "tools_called": tools_called,
                "messages":    messages,
            }

        # Execute each tool call
        for tool_call in message.tool_calls:
            name = tool_call.function.name
            args = json.loads(tool_call.function.arguments)

            print(f"  [Tool] Calling: {name}({list(args.keys())})")
            result = dispatch_tool(name, args)
            tools_called.append({"tool": name, "args": args, "result": json.loads(result)})

            messages.append({
                "role":         "tool",
                "tool_call_id": tool_call.id,
                "content":      result,
            })


# ── Multi-turn conversation ───────────────────────────────────────────────────

def run_conversation():
    """Interactive multi-turn conversation loop."""
    print("=" * 65)
    print("  Financial Fraud Detection and Advisory Assistant")
    print("  IT9204 Individual Project | Student: Hatem Isa (202508993)")
    print("=" * 65)
    print("Type your query below. Type 'exit' to quit.\n")

    history = [{"role": "system", "content": SYSTEM_PROMPT}]

    while True:
        user_input = input("Analyst: ").strip()
        if user_input.lower() in ("exit", "quit", "q"):
            print("Session ended.")
            break
        if not user_input:
            continue

        print("\n[Agent reasoning...]")
        result = run_agent(user_input, history)

        print(f"\nAssistant:\n{result['response']}")
        if result["tools_called"]:
            tool_names = [t["tool"] for t in result["tools_called"]]
            print(f"\n[Tools used: {', '.join(tool_names)}]")
        print()

        # Update history for next turn
        history = result["messages"]


# ── Single-query entry point (for evaluation / integration) ───────────────────

def answer_query(query: str) -> dict:
    """
    Stateless single-query interface used by evaluate.py and main.py.
    """
    return run_agent(query, conversation_history=None)


if __name__ == "__main__":
    run_conversation()
