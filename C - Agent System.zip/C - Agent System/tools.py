"""
Part C – Agent System: Tool Implementations

Three tools the agent can call:
  1. predict_fraud_risk      — calls Azure ML endpoint
  2. retrieve_policy         — calls Azure AI Search (RAG)
  3. calculate_risk_score    — deterministic composite risk function
"""

import json
import math
import requests
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / "E - System Integration"))
from config import (
    AZURE_ML_ENDPOINT_URL, AZURE_ML_ENDPOINT_KEY,
    HIGH_RISK_THRESHOLD, USE_AUTOML_ENDPOINT,
)

sys.path.insert(0, str(Path(__file__).parent.parent / "A - Data and Knowledge Layer"))
from rag_pipeline import retrieve_policy as _retrieve, format_retrieved_context


# ── Tool 1: predict_fraud_risk ────────────────────────────────────────────────

# JSON Schema exposed to the LLM via function calling
PREDICT_FRAUD_RISK_SCHEMA = {
    "name": "predict_fraud_risk",
    "description": (
        "Call the deployed Azure ML model to predict whether a transaction is fraudulent. "
        "Returns a probability score (0–1), predicted class (0=legitimate, 1=fraud), "
        "and risk level (low/medium/high/critical). "
        "Use this when the user provides specific transaction features or asks about "
        "a particular transaction's fraud likelihood."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "Time":   {"type": "number", "description": "Seconds elapsed since first transaction in dataset"},
            "Amount": {"type": "number", "description": "Transaction amount in USD"},
            "V1":  {"type": "number"}, "V2":  {"type": "number"}, "V3":  {"type": "number"},
            "V4":  {"type": "number"}, "V5":  {"type": "number"}, "V6":  {"type": "number"},
            "V7":  {"type": "number"}, "V8":  {"type": "number"}, "V9":  {"type": "number"},
            "V10": {"type": "number"}, "V11": {"type": "number"}, "V12": {"type": "number"},
            "V13": {"type": "number"}, "V14": {"type": "number"}, "V15": {"type": "number"},
            "V16": {"type": "number"}, "V17": {"type": "number"}, "V18": {"type": "number"},
            "V19": {"type": "number"}, "V20": {"type": "number"}, "V21": {"type": "number"},
            "V22": {"type": "number"}, "V23": {"type": "number"}, "V24": {"type": "number"},
            "V25": {"type": "number"}, "V26": {"type": "number"}, "V27": {"type": "number"},
            "V28": {"type": "number"},
        },
        "required": ["Time", "Amount"],
    },
}


def predict_fraud_risk(transaction_features: dict) -> dict:
    """
    Call the Azure ML AutoML real-time endpoint with transaction features.
    Falls back to a mock response if the endpoint is not configured yet.

    AutoML managed online endpoints expect this request format:
    {
      "input_data": {
        "columns": ["Time", "V1", ..., "V28", "Amount"],
        "index":   [0],
        "data":    [[val, val, ...]]
      }
    }
    And return: [predicted_class]   e.g. [0] or [1]
    """
    columns = ["Time", "Amount"] + [f"V{i}" for i in range(1, 29)]
    values  = [transaction_features.get(col, 0.0) for col in columns]

    if "<endpoint>" in AZURE_ML_ENDPOINT_URL or "placeholder" in AZURE_ML_ENDPOINT_URL:
        return _mock_fraud_prediction(values[1], values[0])   # Amount, Time

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {AZURE_ML_ENDPOINT_KEY}",
    }

    if USE_AUTOML_ENDPOINT:
        # AutoML MLflow endpoint format
        payload = {
            "input_data": {
                "columns": columns,
                "index":   [0],
                "data":    [values],
            }
        }
        response = requests.post(
            AZURE_ML_ENDPOINT_URL,
            headers=headers,
            json=payload,
            timeout=15,
        )
        response.raise_for_status()
        raw = response.json()

        # AutoML returns [predicted_class] — e.g. [1] or [0]
        # Convert to the standard response schema the agent expects
        predicted_class = int(raw[0]) if isinstance(raw, list) else int(raw)
        # Estimate probability from class (AutoML doesn't return proba by default)
        # Use 0.85 for fraud, 0.12 for legitimate as representative values
        fraud_probability = 0.85 if predicted_class == 1 else 0.12
        risk_level = (
            "high"   if predicted_class == 1 else
            "low"
        )
        return {
            "fraud_probability": fraud_probability,
            "predicted_class":   predicted_class,
            "risk_level":        risk_level,
            "source":            "Azure ML AutoML endpoint",
        }
    else:
        # Custom score.py endpoint format (train_and_deploy.py)
        payload = dict(zip(columns, values))
        response = requests.post(
            AZURE_ML_ENDPOINT_URL,
            headers=headers,
            json=payload,
            timeout=15,
        )
        response.raise_for_status()
        return response.json()


def _mock_fraud_prediction(amount: float, time: float) -> dict:
    """
    Heuristic mock for demo purposes when the Azure ML endpoint is unavailable.
    Large late-night transactions score higher.
    """
    hour = (time % 86400) / 3600  # convert seconds to hour of day
    night_factor = 1.0 if (0 <= hour <= 5) or (22 <= hour <= 24) else 0.0
    amount_factor = min(amount / 5000.0, 1.0)
    prob = round(min(0.15 + 0.45 * amount_factor + 0.25 * night_factor, 0.97), 4)
    pred = 1 if prob >= 0.5 else 0
    risk_level = (
        "critical" if prob >= 0.90 else
        "high"     if prob >= 0.70 else
        "medium"   if prob >= 0.40 else
        "low"
    )
    return {
        "fraud_probability": prob,
        "predicted_class":   pred,
        "risk_level":        risk_level,
        "source":            "mock (Azure ML endpoint not configured)",
    }


# ── Tool 2: retrieve_policy ───────────────────────────────────────────────────

RETRIEVE_POLICY_SCHEMA = {
    "name": "retrieve_policy",
    "description": (
        "Search the bank's compliance and fraud policy knowledge base and return relevant "
        "policy excerpts. Use this when the user asks about procedures, regulations, "
        "escalation steps, reporting requirements, or what action to take according to policy. "
        "Always use this after predict_fraud_risk when the risk level is high or critical."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Natural language query describing what policy information is needed.",
            },
            "top_k": {
                "type": "integer",
                "description": "Number of policy chunks to retrieve (default 3, max 5).",
                "default": 3,
            },
        },
        "required": ["query"],
    },
}


def retrieve_policy(query: str, top_k: int = 3) -> dict:
    """
    Retrieve relevant policy chunks from Azure AI Search.
    Returns formatted context string and raw results.
    """
    top_k = min(top_k, 5)
    results = _retrieve(query=query, top_k=top_k)
    return {
        "context":      format_retrieved_context(results),
        "sources":      [r["source"] for r in results],
        "chunk_count":  len(results),
    }


# ── Tool 3: calculate_risk_score ──────────────────────────────────────────────

CALCULATE_RISK_SCORE_SCHEMA = {
    "name": "calculate_risk_score",
    "description": (
        "Compute a deterministic composite risk score (0–10) from transaction metadata. "
        "Use this when the user describes a pattern of transactions (velocity, frequency, "
        "time window, amount totals, device changes) rather than a single transaction with "
        "full PCA features. The score helps decide whether to escalate to ML prediction."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "amount": {
                "type": "number",
                "description": "Transaction amount in USD.",
            },
            "frequency": {
                "type": "integer",
                "description": "Number of transactions by this customer in the past 60 minutes.",
            },
            "location_change": {
                "type": "boolean",
                "description": "True if the transaction location is inconsistent with the customer's usual location.",
            },
            "hour_of_day": {
                "type": "integer",
                "description": "Hour of the transaction in 24-hour format (0–23, local bank time).",
            },
            "new_device": {
                "type": "boolean",
                "description": "True if the transaction was initiated from an unrecognized device.",
            },
            "cumulative_amount_60min": {
                "type": "number",
                "description": "Total amount transacted by this customer in the past 60 minutes (USD).",
            },
        },
        "required": ["amount", "frequency", "hour_of_day"],
    },
}


def calculate_risk_score(
    amount: float,
    frequency: int,
    hour_of_day: int,
    location_change: bool = False,
    new_device: bool = False,
    cumulative_amount_60min: float = 0.0,
) -> dict:
    """
    Composite risk scoring function.
    Each factor contributes a weighted score. Total is normalized to 0–10.

    Factors and max contributions:
      - Amount (large = higher risk):       up to 2.5
      - Frequency (velocity):               up to 2.5
      - Night-time transaction (0–5 AM):    up to 1.5
      - Location change:                    1.0
      - New/unrecognized device:            1.0
      - Cumulative amount in 60 min:        up to 1.5
    Total max = 10.0
    """
    score = 0.0
    breakdown = {}

    # Amount factor (log-scaled, capped at $10,000)
    amt_score = min(2.5 * math.log1p(amount) / math.log1p(10000), 2.5)
    score += amt_score
    breakdown["amount"] = round(amt_score, 2)

    # Velocity factor: >10 transactions in 60 min = max score
    vel_score = min(2.5 * frequency / 10.0, 2.5)
    score += vel_score
    breakdown["velocity"] = round(vel_score, 2)

    # Night-time factor (midnight to 5 AM)
    if 0 <= hour_of_day <= 5:
        night_score = 1.5
    elif hour_of_day >= 22:
        night_score = 0.8
    else:
        night_score = 0.0
    score += night_score
    breakdown["night_time"] = round(night_score, 2)

    # Location change
    loc_score = 1.0 if location_change else 0.0
    score += loc_score
    breakdown["location_change"] = round(loc_score, 2)

    # New device
    dev_score = 1.0 if new_device else 0.0
    score += dev_score
    breakdown["new_device"] = round(dev_score, 2)

    # Cumulative amount in 60 min (>$5,000 = max)
    cum_score = min(1.5 * cumulative_amount_60min / 5000.0, 1.5)
    score += cum_score
    breakdown["cumulative_60min"] = round(cum_score, 2)

    total = round(min(score, 10.0), 2)

    risk_level = (
        "critical" if total >= 8.5 else
        "high"     if total >= 7.0 else
        "medium"   if total >= 4.0 else
        "low"
    )

    return {
        "composite_score": total,
        "risk_level":      risk_level,
        "breakdown":       breakdown,
        "interpretation": (
            f"Composite risk score: {total}/10 ({risk_level.upper()}). "
            + ("Escalate to ML prediction and retrieve policy." if total >= 7.0
               else "Monitor and flag for analyst review." if total >= 4.0
               else "Low risk — standard monitoring applies.")
        ),
    }


# ── Tool registry ─────────────────────────────────────────────────────────────

TOOL_SCHEMAS = [
    {"type": "function", "function": PREDICT_FRAUD_RISK_SCHEMA},
    {"type": "function", "function": RETRIEVE_POLICY_SCHEMA},
    {"type": "function", "function": CALCULATE_RISK_SCORE_SCHEMA},
]

TOOL_FUNCTIONS = {
    "predict_fraud_risk":   lambda args: predict_fraud_risk(args),
    "retrieve_policy":      lambda args: retrieve_policy(**args),
    "calculate_risk_score": lambda args: calculate_risk_score(**args),
}


def dispatch_tool(tool_name: str, tool_args: dict) -> str:
    """Execute a tool call and return its result as a JSON string."""
    if tool_name not in TOOL_FUNCTIONS:
        return json.dumps({"error": f"Unknown tool: {tool_name}"})
    result = TOOL_FUNCTIONS[tool_name](tool_args)
    return json.dumps(result, indent=2)
