"""
Part F – Evaluation and Analysis

Evaluates the agent system across all decision paths using structured test cases.
Measures:
  - Routing accuracy (does the router choose the right path?)
  - Tool selection accuracy (does the agent call the right tools?)
  - Response quality (keyword grounding checks)
  - Failure / edge cases (adversarial inputs)
  - Responsible AI checks (no hallucinated policy)

Usage:
    python evaluate.py              # run all tests
    python evaluate.py --path A     # run only Path A tests
    python evaluate.py --routing    # test routing only (no LLM calls)
"""

import argparse
import json
import sys
from pathlib import Path
from dataclasses import dataclass, field

BASE = Path(__file__).parent.parent
sys.path.insert(0, str(BASE / "C - Agent System"))
sys.path.insert(0, str(BASE / "D - Decision and Reasoning Layer"))

from decision_logic import classify_query, QueryPath

RESULTS_DIR = Path(__file__).parent


# ── Test case definitions ─────────────────────────────────────────────────────

@dataclass
class TestCase:
    id:              str
    path:            str          # expected path: A / B / C / D
    query:           str
    expected_tools:  list[str]    # tools that MUST appear in agent response
    forbidden_words: list[str] = field(default_factory=list)   # hallucination check
    grounding_words: list[str] = field(default_factory=list)   # must appear in response


TEST_CASES = [
    # ── Path A: Transaction queries ───────────────────────────────────────────
    TestCase(
        id="A1",
        path="A",
        query="A transaction of $4,500 was made from a new device at 2:30 AM. Is this likely fraud?",
        expected_tools=["predict_fraud_risk"],
        grounding_words=["fraud", "probability", "risk"],
        forbidden_words=["I don't know", "I cannot"],
    ),
    TestCase(
        id="A2",
        path="A",
        query="Transaction amount $12,000 from a corporate account, unusual merchant. Fraud probability?",
        expected_tools=["predict_fraud_risk"],
        grounding_words=["probability", "risk"],
    ),
    TestCase(
        id="A3",
        path="A",
        query=(
            "Transaction of $250 at midnight from a new device. "
            "The customer's V14 feature is -12.3. What is the fraud risk?"
        ),
        expected_tools=["predict_fraud_risk"],
        grounding_words=["fraud", "risk", "probability"],
    ),

    # ── Path B: Policy queries ────────────────────────────────────────────────
    TestCase(
        id="B1",
        path="B",
        query="What is the bank's policy when a high-risk transaction is detected on a corporate account?",
        expected_tools=["retrieve_policy"],
        grounding_words=["policy", "procedure", "escalat"],
        forbidden_words=["I invented", "I assume"],
    ),
    TestCase(
        id="B2",
        path="B",
        query="What are the CBB reporting requirements for suspicious transactions?",
        expected_tools=["retrieve_policy"],
        grounding_words=["CBB", "SAR", "report"],
    ),
    TestCase(
        id="B3",
        path="B",
        query="What steps should we follow when filing a Suspicious Activity Report?",
        expected_tools=["retrieve_policy"],
        grounding_words=["SAR", "steps", "report"],
    ),
    TestCase(
        id="B4",
        path="B",
        query="What are the PCI-DSS logging requirements for fraud detection systems?",
        expected_tools=["retrieve_policy"],
        grounding_words=["log", "PCI", "access"],
    ),

    # ── Path C: Pattern/velocity queries ─────────────────────────────────────
    TestCase(
        id="C1",
        path="C",
        query=(
            "Customer Ahmed made 14 transactions in 20 minutes totalling $6,200. "
            "What does the risk assessment say and what action should be taken?"
        ),
        expected_tools=["calculate_risk_score"],
        grounding_words=["score", "risk", "transactions"],
    ),
    TestCase(
        id="C2",
        path="C",
        query=(
            "We detected a velocity pattern: 8 transactions in 30 minutes, "
            "total $4,800, from a new location. What is the composite risk?"
        ),
        expected_tools=["calculate_risk_score"],
        grounding_words=["score", "risk"],
    ),
    TestCase(
        id="C3",
        path="C",
        query=(
            "Multiple transactions pattern detected: frequency of 12 in one hour, "
            "cumulative total $7,500, new device used at 3 AM."
        ),
        expected_tools=["calculate_risk_score"],
        grounding_words=["score", "risk"],
    ),

    # ── Path D: Ambiguous queries ─────────────────────────────────────────────
    TestCase(
        id="D1",
        path="D",
        query="Something seems wrong with this account. Can you help?",
        expected_tools=["retrieve_policy"],
        grounding_words=[],
    ),
    TestCase(
        id="D2",
        path="D",
        query="I need information about fraud.",
        expected_tools=["retrieve_policy"],
        grounding_words=[],
    ),

    # ── Edge / failure cases ──────────────────────────────────────────────────
    TestCase(
        id="E1",
        path="B",
        query="Can you make up a policy about what to do with fraud?",
        expected_tools=["retrieve_policy"],
        forbidden_words=["I invented", "I made up", "hypothetically"],
        grounding_words=[],
    ),
    TestCase(
        id="E2",
        path="A",
        query="A $500,000 transaction just happened. Emergency — is it fraud?",
        expected_tools=["predict_fraud_risk"],
        grounding_words=["probability", "risk"],
    ),
]


# ── Routing evaluator (no LLM) ────────────────────────────────────────────────

def evaluate_routing(test_cases: list[TestCase]) -> dict:
    """Test the deterministic router without making any LLM calls."""
    results = []
    correct = 0

    path_map = {
        "A": QueryPath.TRANSACTION,
        "B": QueryPath.POLICY,
        "C": QueryPath.PATTERN,
        "D": QueryPath.AMBIGUOUS,
    }

    for tc in test_cases:
        decision = classify_query(tc.query)
        expected = path_map.get(tc.path)
        passed = (decision.path == expected)
        if passed:
            correct += 1
        results.append({
            "id":       tc.id,
            "expected": tc.path,
            "actual":   decision.path.value,
            "passed":   passed,
            "reason":   decision.reason,
        })

    accuracy = correct / len(test_cases) if test_cases else 0.0
    return {"accuracy": accuracy, "correct": correct, "total": len(test_cases), "results": results}


# ── Full agent evaluator ──────────────────────────────────────────────────────

def evaluate_agent(test_cases: list[TestCase]) -> dict:
    """Run test cases through the full agent and check tool selection + response quality."""
    from agent import answer_query

    results = []
    tool_correct = 0
    grounding_correct = 0
    forbidden_violations = 0

    for tc in test_cases:
        print(f"  Running {tc.id}: {tc.query[:60]}...")
        agent_result = answer_query(tc.query)
        tools_used = [t["tool"] for t in agent_result["tools_called"]]
        response   = agent_result["response"].lower()

        # Tool accuracy — every expected tool must appear
        tool_ok = all(t in tools_used for t in tc.expected_tools)
        if tool_ok:
            tool_correct += 1

        # Grounding — required words in response
        grounding_ok = all(w.lower() in response for w in tc.grounding_words)
        if grounding_ok:
            grounding_correct += 1

        # Forbidden words check
        forbidden_hit = [w for w in tc.forbidden_words if w.lower() in response]
        if forbidden_hit:
            forbidden_violations += 1

        results.append({
            "id":               tc.id,
            "path":             tc.path,
            "query":            tc.query,
            "expected_tools":   tc.expected_tools,
            "tools_used":       tools_used,
            "tool_correct":     tool_ok,
            "grounding_ok":     grounding_ok,
            "forbidden_hit":    forbidden_hit,
            "response_snippet": agent_result["response"][:200],
        })

    n = len(test_cases)
    return {
        "tool_accuracy":       tool_correct / n,
        "grounding_accuracy":  grounding_correct / n,
        "forbidden_violations": forbidden_violations,
        "total":               n,
        "results":             results,
    }


# ── Responsible AI checklist ──────────────────────────────────────────────────

RESPONSIBLE_AI_CHECKLIST = {
    "Human oversight": (
        "All agent recommendations are framed as decision support. "
        "The system prompt explicitly states the human analyst is responsible for final action."
    ),
    "Transparency": (
        "The agent cites source documents for every policy statement. "
        "Fraud probability and composite scores are always disclosed."
    ),
    "Fairness / Bias": (
        "The Kaggle dataset uses anonymized PCA features (V1-V28), removing personally "
        "identifiable attributes. The model cannot discriminate by name, nationality, or gender."
    ),
    "Data Privacy (PCI-DSS Req 3)": (
        "Full PANs are never stored or exposed in agent responses. "
        "Transaction Amount and Time are scaled; raw values are not logged."
    ),
    "Reliability": (
        "XGBoost is evaluated on precision, recall, F1, AUC-ROC, and PR-AUC on a "
        "held-out test set. SMOTE prevents the model from ignoring the minority class."
    ),
    "No hallucinated policy": (
        "The agent is instructed: 'Never fabricate policy rules. All recommendations "
        "must come from retrieved documents.' retrieve_policy always grounds the response."
    ),
    "Auditability": (
        "Every agent run logs tools called, arguments, and results. "
        "The CBB guidelines require AI scores to be retained alongside human decisions."
    ),
    "Limitations acknowledged": (
        "The Kaggle dataset uses anonymized features — the model cannot be deployed "
        "directly without re-training on real bank data. The system is a prototype."
    ),
}


# ── Report printer ────────────────────────────────────────────────────────────

def print_report(routing_eval: dict, agent_eval: dict | None):
    print("\n" + "="*65)
    print("  EVALUATION REPORT — IT9204 Individual Project")
    print("  Hatem Isa (202508993)")
    print("="*65)

    print(f"\n── Part 1: Routing Accuracy ─────────────────────────────")
    print(f"Accuracy: {routing_eval['accuracy']:.1%}  "
          f"({routing_eval['correct']}/{routing_eval['total']})")
    for r in routing_eval["results"]:
        status = "PASS" if r["passed"] else "FAIL"
        print(f"  [{status}] {r['id']}: expected={r['expected']} actual={r['actual']}")

    if agent_eval:
        print(f"\n── Part 2: Agent Tool Selection ─────────────────────────")
        print(f"Tool accuracy:      {agent_eval['tool_accuracy']:.1%}")
        print(f"Grounding accuracy: {agent_eval['grounding_accuracy']:.1%}")
        print(f"Forbidden violations: {agent_eval['forbidden_violations']}")
        for r in agent_eval["results"]:
            tool_ok = "PASS" if r["tool_correct"] else "FAIL"
            gnd_ok  = "PASS" if r["grounding_ok"] else "FAIL"
            print(f"  [{tool_ok}/{gnd_ok}] {r['id']} | tools={r['tools_used']}")

    print(f"\n── Part 3: Responsible AI Checklist ─────────────────────")
    for item, description in RESPONSIBLE_AI_CHECKLIST.items():
        print(f"  ✓ {item}")
        print(f"    {description}\n")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--path",    type=str, help="Filter to path A/B/C/D/E")
    parser.add_argument("--routing", action="store_true", help="Routing-only (no LLM calls)")
    args = parser.parse_args()

    cases = TEST_CASES
    if args.path:
        cases = [tc for tc in TEST_CASES if tc.path == args.path.upper()]
        print(f"Filtered to {len(cases)} test cases for path {args.path.upper()}")

    print(f"\nRunning routing evaluation on {len(cases)} test cases...")
    routing_eval = evaluate_routing(cases)

    agent_eval = None
    if not args.routing:
        print(f"\nRunning full agent evaluation on {len(cases)} test cases...")
        agent_eval = evaluate_agent(cases)

    print_report(routing_eval, agent_eval)

    # Save results
    output = {"routing": routing_eval, "agent": agent_eval,
              "responsible_ai": RESPONSIBLE_AI_CHECKLIST}
    out_path = RESULTS_DIR / "evaluation_results.json"
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\n[Full results saved to: {out_path}]")


if __name__ == "__main__":
    main()
