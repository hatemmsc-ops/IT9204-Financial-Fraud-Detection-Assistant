"""
Creates a smaller sampled version of creditcard.csv for Azure ML AutoML.
Keeps ALL fraud cases + a random sample of legitimate transactions.

Run from this folder:
    python sample_dataset.py

Output: creditcard_sampled.csv  (~10,000 rows, upload this to Azure ML)
"""

import pandas as pd

FULL_CSV    = "creditcard.csv"
OUTPUT_CSV  = "creditcard_sampled.csv"
LEGIT_SAMPLE = 9500   # legitimate transactions to keep
RANDOM_SEED  = 42

df = pd.read_csv(FULL_CSV)

fraud  = df[df["Class"] == 1]          # keep ALL 492 fraud cases
legit  = df[df["Class"] == 0].sample(n=LEGIT_SAMPLE, random_state=RANDOM_SEED)

sampled = pd.concat([fraud, legit]).sample(frac=1, random_state=RANDOM_SEED)
sampled.reset_index(drop=True, inplace=True)

sampled.to_csv(OUTPUT_CSV, index=False)

print(f"Original : {len(df):,} rows")
print(f"Sampled  : {len(sampled):,} rows")
print(f"  Fraud  : {sampled['Class'].sum()} ({sampled['Class'].mean():.2%})")
print(f"  Legit  : {(sampled['Class']==0).sum()}")
print(f"Saved to : {OUTPUT_CSV}")
print("\nUpload creditcard_sampled.csv to Azure ML (not the full file).")
