# Dataset — Kaggle Credit Card Fraud Detection

## Download Instructions

1. Go to: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
2. Click **Download** (requires a free Kaggle account)
3. Extract and place `creditcard.csv` in **this folder**

## Dataset Facts

| Property | Value |
|---|---|
| Source | Kaggle / ULB Machine Learning Group |
| Rows | 284,807 transactions |
| Fraud rate | 0.172% (492 fraud cases) |
| Features | Time, Amount, V1–V28 (PCA-anonymized), Class |
| Target | Class (0 = legitimate, 1 = fraud) |
| License | Open Database License (ODbL) |

## Privacy Note

V1–V28 are PCA-transformed features from real European cardholder transactions.
The PCA transformation removes all personally identifiable information (names,
card numbers, locations). This is compliant with PCI-DSS Requirement 3.

## Usage

```bash
# From the model/ folder
python train_and_deploy.py --train
```

The script reads `../dataset/creditcard.csv` automatically.
