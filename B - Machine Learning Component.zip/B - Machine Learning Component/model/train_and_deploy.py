"""
Part B – Machine Learning Component
Train an XGBoost fraud classification model on the Kaggle Credit Card Fraud dataset,
evaluate it, and deploy it as an Azure ML real-time endpoint.

Dataset: https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud
Place creditcard.csv in:  ../dataset/creditcard.csv

Usage:
    python train_and_deploy.py --train          # train locally and save model
    python train_and_deploy.py --deploy         # deploy saved model to Azure ML
    python train_and_deploy.py --train --deploy # do both
"""

# %% [Cell 1] Imports
import argparse
import os
import sys
import json
import joblib
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, roc_curve, precision_recall_curve, average_precision_score,
)
from imblearn.over_sampling import SMOTE
from xgboost import XGBClassifier

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "E - System Integration"))
from config import AZURE_ML_ENDPOINT_URL, AZURE_ML_ENDPOINT_KEY

DATASET_PATH = Path(__file__).parent.parent / "dataset" / "creditcard.csv"
MODEL_PATH   = Path(__file__).parent / "fraud_model.joblib"
SCALER_PATH  = Path(__file__).parent / "scaler.joblib"
RESULTS_DIR  = Path(__file__).parent.parent.parent / "F - Evaluation and Analysis"


# %% [Cell 2] Load and explore data
def load_data():
    print("Loading dataset...")
    df = pd.read_csv(DATASET_PATH)
    print(f"Shape: {df.shape}")
    print(f"Fraud rate: {df['Class'].mean():.4%}  ({df['Class'].sum()} fraud out of {len(df)})")
    print(df.describe()[["Amount", "Time"]].round(2))
    return df


# %% [Cell 3] Preprocess
def preprocess(df: pd.DataFrame):
    """
    Features: Time, Amount, V1-V28
    Scale Time and Amount (V1-V28 already PCA-transformed, zero-mean).
    Apply SMOTE to handle extreme class imbalance (0.17% fraud).
    """
    X = df.drop(columns=["Class"])
    y = df["Class"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Scale Time and Amount
    scaler = StandardScaler()
    X_train[["Time", "Amount"]] = scaler.fit_transform(X_train[["Time", "Amount"]])
    X_test[["Time", "Amount"]]  = scaler.transform(X_test[["Time", "Amount"]])

    print(f"\nTrain size: {X_train.shape}, Test size: {X_test.shape}")
    print(f"Train fraud count (before SMOTE): {y_train.sum()}")

    # SMOTE oversampling on training set only
    sm = SMOTE(random_state=42, sampling_strategy=0.1)  # 10% minority ratio
    X_train_res, y_train_res = sm.fit_resample(X_train, y_train)
    print(f"Train fraud count (after SMOTE):  {y_train_res.sum()}")
    print(f"Resampled train size: {X_train_res.shape}")

    return X_train_res, X_test, y_train_res, y_test, scaler


# %% [Cell 4] Train
def train_model(X_train, y_train):
    """
    XGBoost with scale_pos_weight as secondary imbalance control.
    scale_pos_weight = negative / positive (on resampled data).
    """
    neg = (y_train == 0).sum()
    pos = (y_train == 1).sum()
    scale = neg / pos

    model = XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale,
        use_label_encoder=False,
        eval_metric="aucpr",          # area under precision-recall curve
        random_state=42,
        n_jobs=-1,
    )

    print("\nTraining XGBoost model...")
    model.fit(
        X_train, y_train,
        eval_set=[(X_train, y_train)],
        verbose=50,
    )
    print("Training complete.")
    return model


# %% [Cell 5] Evaluate
def evaluate_model(model, X_test, y_test, scaler):
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("\n── Classification Report ──────────────────────────────")
    print(classification_report(y_test, y_pred, target_names=["Legitimate", "Fraud"], digits=4))

    roc_auc = roc_auc_score(y_test, y_proba)
    pr_auc  = average_precision_score(y_test, y_proba)
    print(f"AUC-ROC:                 {roc_auc:.4f}")
    print(f"Average Precision (PRAUC): {pr_auc:.4f}")

    # Confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Legitimate", "Fraud"],
                yticklabels=["Legitimate", "Fraud"])
    plt.title("Confusion Matrix")
    plt.ylabel("Actual"); plt.xlabel("Predicted")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "confusion_matrix.png", dpi=150)
    plt.close()

    # ROC curve
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f"XGBoost (AUC={roc_auc:.4f})")
    plt.plot([0, 1], [0, 1], "k--")
    plt.xlabel("False Positive Rate"); plt.ylabel("True Positive Rate")
    plt.title("ROC Curve – Fraud Detection Model")
    plt.legend(); plt.tight_layout()
    plt.savefig(RESULTS_DIR / "roc_curve.png", dpi=150)
    plt.close()

    # Precision-Recall curve
    prec, rec, _ = precision_recall_curve(y_test, y_proba)
    plt.figure(figsize=(6, 5))
    plt.plot(rec, prec, label=f"XGBoost (PRAUC={pr_auc:.4f})")
    plt.xlabel("Recall"); plt.ylabel("Precision")
    plt.title("Precision-Recall Curve – Fraud Detection Model")
    plt.legend(); plt.tight_layout()
    plt.savefig(RESULTS_DIR / "precision_recall_curve.png", dpi=150)
    plt.close()

    # Feature importance (top 15)
    feat_imp = pd.Series(model.feature_importances_, index=X_test.columns)
    top15 = feat_imp.nlargest(15)
    plt.figure(figsize=(7, 5))
    top15.sort_values().plot(kind="barh", color="steelblue")
    plt.title("Top 15 Feature Importances – XGBoost")
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / "feature_importance.png", dpi=150)
    plt.close()

    print(f"\nPlots saved to: {RESULTS_DIR}")

    # Save metrics JSON for report
    metrics = {
        "roc_auc":            round(roc_auc, 4),
        "pr_auc":             round(pr_auc, 4),
        "test_fraud_count":   int(y_test.sum()),
        "test_total":         int(len(y_test)),
    }
    with open(RESULTS_DIR / "ml_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    return metrics


# %% [Cell 6] Save model
def save_model(model, scaler):
    joblib.dump(model,  MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    print(f"\nModel saved to:  {MODEL_PATH}")
    print(f"Scaler saved to: {SCALER_PATH}")


# %% [Cell 7] Deploy to Azure ML
def deploy_to_azure_ml():
    """
    Registers and deploys the trained model to Azure ML as a managed online endpoint.
    Requires azure-ai-ml SDK and an Azure ML workspace.
    """
    from azure.ai.ml import MLClient
    from azure.ai.ml.entities import (
        ManagedOnlineEndpoint, ManagedOnlineDeployment,
        Model, Environment, CodeConfiguration,
    )
    from azure.identity import DefaultAzureCredential

    # Read workspace config from environment variables
    subscription_id = os.environ["AZURE_SUBSCRIPTION_ID"]
    resource_group  = os.environ["AZURE_RESOURCE_GROUP"]
    workspace_name  = os.environ["AZURE_ML_WORKSPACE"]

    ml_client = MLClient(
        DefaultAzureCredential(),
        subscription_id,
        resource_group,
        workspace_name,
    )

    # Register model
    registered_model = ml_client.models.create_or_update(
        Model(
            path=str(MODEL_PATH),
            name="fraud-detection-xgboost",
            description="XGBoost binary classifier for credit card fraud detection.",
        )
    )
    print(f"Registered model: {registered_model.name} v{registered_model.version}")

    # Create endpoint
    endpoint_name = "fraud-detection-endpoint"
    endpoint = ManagedOnlineEndpoint(
        name=endpoint_name,
        description="Real-time fraud prediction endpoint",
        auth_mode="key",
    )
    ml_client.online_endpoints.begin_create_or_update(endpoint).result()
    print(f"Endpoint created: {endpoint_name}")

    # Create deployment using scoring script
    deployment = ManagedOnlineDeployment(
        name="fraud-v1",
        endpoint_name=endpoint_name,
        model=registered_model,
        code_configuration=CodeConfiguration(
            code=str(Path(__file__).parent),
            scoring_script="score.py",
        ),
        environment=Environment(
            conda_file=str(Path(__file__).parent / "conda_env.yml"),
            image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04:latest",
        ),
        instance_type="Standard_DS2_v2",
        instance_count=1,
    )
    ml_client.online_deployments.begin_create_or_update(deployment).result()

    # Route all traffic to this deployment
    endpoint.traffic = {"fraud-v1": 100}
    ml_client.online_endpoints.begin_create_or_update(endpoint).result()
    print("Deployment complete. Endpoint is live.")

    # Print the scoring URI and key
    endpoint_obj = ml_client.online_endpoints.get(endpoint_name)
    keys = ml_client.online_endpoints.get_keys(endpoint_name)
    print(f"\nEndpoint URI: {endpoint_obj.scoring_uri}")
    print(f"Primary key:  {keys.primary_key}")
    print("\nAdd these to your .env file as AZURE_ML_ENDPOINT_URL and AZURE_ML_ENDPOINT_KEY.")


# %% [Cell 8] Main
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--train",  action="store_true")
    parser.add_argument("--deploy", action="store_true")
    args = parser.parse_args()

    if not args.train and not args.deploy:
        parser.print_help()
        return

    if args.train:
        df = load_data()
        X_train, X_test, y_train, y_test, scaler = preprocess(df)
        model = train_model(X_train, y_train)
        evaluate_model(model, X_test, y_test, scaler)
        save_model(model, scaler)

    if args.deploy:
        deploy_to_azure_ml()


if __name__ == "__main__":
    main()
