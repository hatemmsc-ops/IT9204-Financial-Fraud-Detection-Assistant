"""
Part B – Machine Learning Component (AutoML approach — Lab 3.1 method)
========================================================================
IMPORTANT: The tutor indicated Lab 3.1 (AutoML on Azure) is important for
the project. This script uses Azure ML AutoML via the Python SDK to train
the fraud detection classifier, which mirrors what you did in Lab 3.1 but
programmatically rather than through the Studio UI.

Why AutoML for the project?
- AutoML tries many algorithms (LightGBM, XGBoost, RandomForest, VotingEnsemble…)
  and selects the best model automatically.
- AUCWeighted is the correct primary metric for the fraud dataset (0.17% fraud
  rate = extreme class imbalance — same note from Lab 3.1).
- The best model is deployed as a real-time endpoint, which the agent calls as
  the predict_fraud_risk tool.

Usage:
    # Option A — run the AutoML job (submits to Azure ML)
    python automl_train_and_deploy.py --run

    # Option B — deploy an already-completed AutoML job's best model
    python automl_train_and_deploy.py --deploy --job-name <automl-job-name>

    # Option C — test the deployed endpoint
    python automl_train_and_deploy.py --test

Prerequisites:
    pip install azure-ai-ml azure-identity
    Set environment variables: AZURE_SUBSCRIPTION_ID, AZURE_RESOURCE_GROUP,
    AZURE_ML_WORKSPACE
    Place creditcard.csv in ../dataset/creditcard.csv
"""

import argparse
import json
import os
import time
from pathlib import Path

# ── Azure ML SDK v2 ───────────────────────────────────────────────────────────
from azure.ai.ml import MLClient, Input
from azure.ai.ml.constants import AssetTypes
from azure.ai.ml.automl import classification
from azure.ai.ml.entities import (
    ManagedOnlineEndpoint,
    ManagedOnlineDeployment,
)
from azure.identity import DefaultAzureCredential

DATASET_PATH   = Path(__file__).parent.parent / "dataset" / "creditcard.csv"
EXPERIMENT_NAME = "fraud-detection-automl"
ENDPOINT_NAME   = "fraud-detection-endpoint"
DEPLOYMENT_NAME = "automl-best-v1"


# ── Azure ML client ───────────────────────────────────────────────────────────

def get_ml_client() -> MLClient:
    return MLClient(
        DefaultAzureCredential(
            exclude_environment_credential=True,
            exclude_managed_identity_credential=True,
        ),
        subscription_id=os.environ["AZURE_SUBSCRIPTION_ID"],
        resource_group_name=os.environ["AZURE_RESOURCE_GROUP"],
        workspace_name=os.environ["AZURE_ML_WORKSPACE"],
    )


# ── Step 1: Register dataset as Azure ML data asset ──────────────────────────

def register_dataset(ml_client: MLClient) -> str:
    """Upload creditcard.csv and register it as a tabular data asset."""
    from azure.ai.ml.entities import Data
    from azure.ai.ml.constants import AssetTypes

    data_asset = Data(
        name="creditcard-fraud",
        path=str(DATASET_PATH),
        type=AssetTypes.URI_FILE,
        description="Kaggle Credit Card Fraud Detection dataset (284,807 transactions)",
    )
    registered = ml_client.data.create_or_update(data_asset)
    print(f"Registered data asset: {registered.name} v{registered.version}")
    return registered.id


# ── Step 2: Submit AutoML classification job ──────────────────────────────────

def run_automl_job(ml_client: MLClient, data_asset_id: str) -> str:
    """
    Submit an AutoML classification job.
    Primary metric: AUCWeighted — correct for imbalanced fraud data (Lab 3.1 note).
    """
    from azure.ai.ml.automl import classification
    from azure.ai.ml import Input
    from azure.ai.ml.constants import AssetTypes

    # Create a compute cluster if needed (or use serverless)
    # For this lab: use the same compute instance you created in Lab 3.1
    compute_name = os.environ.get("AZURE_ML_COMPUTE", "automl-compute")

    automl_job = classification(
        compute=compute_name,
        experiment_name=EXPERIMENT_NAME,
        training_data=Input(type=AssetTypes.URI_FILE, path=data_asset_id),
        target_column_name="Class",           # 0 = legitimate, 1 = fraud
        primary_metric="AUCWeighted",         # best metric for class imbalance
        enable_model_explainability=True,     # show feature importance
        n_cross_validations=2,                # k-fold cross-validation (Lab 3.1 setting)
        test_data_size=0.20,                  # 20% held out for test
        timeout_minutes=60,                   # stop after 1 hour
        max_trials=10,                        # try up to 10 algorithm combinations
    )

    returned_job = ml_client.jobs.create_or_update(automl_job)
    print(f"AutoML job submitted: {returned_job.name}")
    print(f"Monitor at: {returned_job.studio_url}")
    print("Waiting for completion (this takes 10-60 minutes)...")

    # Poll for completion
    while True:
        job = ml_client.jobs.get(returned_job.name)
        print(f"  Status: {job.status}")
        if job.status in ("Completed", "Failed", "Canceled"):
            break
        time.sleep(60)

    if job.status != "Completed":
        raise RuntimeError(f"AutoML job {returned_job.name} ended with status: {job.status}")

    return returned_job.name


# ── Step 3: Deploy best model as real-time endpoint ───────────────────────────

def deploy_best_model(ml_client: MLClient, job_name: str):
    """
    Find the best model from the AutoML job and deploy it as a managed
    online endpoint. Mirrors the 'Deploy > Real-time endpoint' step in Lab 3.1.
    """
    # Get the best model from the completed AutoML run
    best_model = ml_client.jobs.get(job_name).properties.get("best_child_run_id")
    print(f"Best model run ID: {best_model}")

    # Register the best model
    from azure.ai.ml.entities import Model
    registered_model = ml_client.models.create_or_update(
        Model(
            path=f"azureml://jobs/{job_name}/outputs/best_model",
            name="fraud-detection-automl-best",
            description="Best AutoML model for fraud detection (AUCWeighted)",
        )
    )
    print(f"Registered: {registered_model.name} v{registered_model.version}")

    # Create endpoint
    endpoint = ManagedOnlineEndpoint(
        name=ENDPOINT_NAME,
        description="Fraud detection real-time endpoint (AutoML best model)",
        auth_mode="key",
    )
    ml_client.online_endpoints.begin_create_or_update(endpoint).result()
    print(f"Endpoint created: {ENDPOINT_NAME}")

    # Deploy
    deployment = ManagedOnlineDeployment(
        name=DEPLOYMENT_NAME,
        endpoint_name=ENDPOINT_NAME,
        model=registered_model,
        instance_type="Standard_DS2_v2",
        instance_count=1,
    )
    ml_client.online_deployments.begin_create_or_update(deployment).result()

    # Route 100% traffic
    endpoint.traffic = {DEPLOYMENT_NAME: 100}
    ml_client.online_endpoints.begin_create_or_update(endpoint).result()

    # Print scoring URI and key
    endpoint_obj = ml_client.online_endpoints.get(ENDPOINT_NAME)
    keys = ml_client.online_endpoints.get_keys(ENDPOINT_NAME)
    print(f"\nEndpoint URI: {endpoint_obj.scoring_uri}")
    print(f"Primary key:  {keys.primary_key}")
    print("\nAdd these to your .env file as AZURE_ML_ENDPOINT_URL and AZURE_ML_ENDPOINT_KEY.")


# ── Step 4: Test the deployed endpoint ───────────────────────────────────────

def test_endpoint(ml_client: MLClient):
    """Send a sample transaction to the deployed endpoint and print the result."""
    import requests

    endpoint_obj = ml_client.online_endpoints.get(ENDPOINT_NAME)
    keys = ml_client.online_endpoints.get_keys(ENDPOINT_NAME)

    # Sample transaction: all V features = 0 (neutral), $4500 at 2:30 AM
    sample = {"Time": 9000, "Amount": 4500.0}
    for i in range(1, 29):
        sample[f"V{i}"] = 0.0

    response = requests.post(
        endpoint_obj.scoring_uri,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {keys.primary_key}",
        },
        json=sample,
        timeout=10,
    )
    print(f"Response ({response.status_code}):")
    print(json.dumps(response.json(), indent=2))


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run",       action="store_true", help="Submit AutoML job")
    parser.add_argument("--deploy",    action="store_true", help="Deploy best model")
    parser.add_argument("--test",      action="store_true", help="Test endpoint")
    parser.add_argument("--job-name",  type=str, help="AutoML job name (for --deploy)")
    args = parser.parse_args()

    ml_client = get_ml_client()

    if args.run:
        data_id = register_dataset(ml_client)
        job_name = run_automl_job(ml_client, data_id)
        print(f"\nAutoML job completed: {job_name}")
        print("Run with --deploy --job-name", job_name, "to deploy the best model.")

    if args.deploy:
        if not args.job_name:
            parser.error("--deploy requires --job-name")
        deploy_best_model(ml_client, args.job_name)

    if args.test:
        test_endpoint(ml_client)

    if not any([args.run, args.deploy, args.test]):
        parser.print_help()


if __name__ == "__main__":
    main()
