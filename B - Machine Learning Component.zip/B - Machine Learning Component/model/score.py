"""
Azure ML scoring script — deployed at the real-time endpoint.
Receives transaction features, returns fraud probability and predicted class.
"""

import json
import joblib
import numpy as np
import os
from pathlib import Path


def init():
    global model, scaler
    model_dir = os.getenv("AZUREML_MODEL_DIR", str(Path(__file__).parent))
    model  = joblib.load(os.path.join(model_dir, "fraud_model.joblib"))
    scaler = joblib.load(os.path.join(model_dir, "scaler.joblib"))


def run(raw_data: str) -> str:
    """
    Input JSON schema:
    {
        "Time":   float,
        "Amount": float,
        "V1": float, ..., "V28": float
    }

    Output JSON schema:
    {
        "fraud_probability": float,   // 0.0 – 1.0
        "predicted_class":   int,     // 0 = legitimate, 1 = fraud
        "risk_level":        str      // "low" | "medium" | "high" | "critical"
    }
    """
    data = json.loads(raw_data)

    feature_cols = ["Time", "Amount"] + [f"V{i}" for i in range(1, 29)]
    X = np.array([[data[col] for col in feature_cols]])

    # Scale Time and Amount (indices 0 and 1)
    X[:, [0, 1]] = scaler.transform(X[:, [0, 1]])

    prob = float(model.predict_proba(X)[0][1])
    pred = int(prob >= 0.5)

    if prob < 0.40:
        risk_level = "low"
    elif prob < 0.70:
        risk_level = "medium"
    elif prob < 0.90:
        risk_level = "high"
    else:
        risk_level = "critical"

    return json.dumps({
        "fraud_probability": round(prob, 4),
        "predicted_class":   pred,
        "risk_level":        risk_level,
    })
