"""
Part D – Decision & Reasoning Layer

This module implements the explicit routing and reasoning strategy that governs
when the agent uses RAG, the ML model, or the composite risk function.

The agent (agent.py) uses Azure OpenAI function calling as the PRIMARY decision
mechanism — the LLM reads the system prompt and decides which tools to call.

This module provides the DETERMINISTIC FALLBACK layer used by main.py and
evaluate.py to classify queries before handing them to the agent. This dual
approach demonstrates that decision logic is transparent, testable, and does not
rely entirely on the LLM's internal reasoning.

Decision Paths
--------------
Path A – Specific Transaction
    Trigger : user provides transaction features (amount, device, time, V features)
    Tools   : predict_fraud_risk → [if score ≥ 0.70] retrieve_policy

Path B – Policy / Procedure Query
    Trigger : user asks "what should we do", "what is the policy", "steps to take"
    Tools   : retrieve_policy only

Path C – Pattern / Velocity Query
    Trigger : user describes multiple transactions, frequency, time windows, totals
    Tools   : calculate_risk_score → [if score ≥ 7.0] predict_fraud_risk + retrieve_policy

Path D – Ambiguous
    Trigger : none of the above match clearly
    Tools   : retrieve_policy (safe default — grounded policy response)
"""

import re
from dataclasses import dataclass
from enum import Enum


class QueryPath(Enum):
    TRANSACTION = "A"   # single transaction → ML prediction
    POLICY      = "B"   # procedure / policy question → RAG only
    PATTERN     = "C"   # velocity / pattern → composite score → ML + RAG
    AMBIGUOUS   = "D"   # unclear → RAG fallback


@dataclass
class RoutingDecision:
    path:              QueryPath
    use_ml:            bool
    use_rag:           bool
    use_risk_score:    bool
    reason:            str


# ── Keyword sets ──────────────────────────────────────────────────────────────

_TRANSACTION_SIGNALS = [
    r"\$[\d,]+",                   # dollar amount e.g. $4,500
    r"\b\d+[\.,]\d{2}\b",         # decimal amount
    r"\bnew device\b",
    r"\bunrecognized device\b",
    r"\b\d{1,2}:\d{2}\s*(am|pm)\b",  # time of day
    r"\btransaction\b.*\b(amount|value)\b",
    r"\bsingle transaction\b",
    r"\bV\d{1,2}\b",              # PCA feature names
    r"\bprobability\b",
    r"\bfraud risk\b",
    r"\bemergency\b",
    r"\bjust happened\b",
]

_POLICY_SIGNALS = [
    r"\bpolicy\b",
    r"\bprocedure\b",
    r"\bwhat (should|must|do) (we|the bank|staff)\b",
    r"\bsteps? to (take|follow)\b",
    r"\bescalat",
    r"\bregulat",
    r"\bcompl[yi]",
    r"\bSAR\b",
    r"\bSTR\b",
    r"\breport(ing)?\b",
    r"\bCBB\b",
    r"\bPCI.?DSS\b",
    r"\bAML\b",
    r"\bKYC\b",
    r"\baction (to take|required)\b",
]

_PATTERN_SIGNALS = [
    r"\b\d+\s+transactions?\b",    # "14 transactions"
    r"\bin \d+ minutes?\b",        # "in 20 minutes"
    r"\bvelocity\b",
    r"\bfrequency\b",
    r"\bpattern\b",
    r"\bmultiple transactions?\b",
    r"\btotal(l?ing)?\b",
    r"\bcumulat",
    r"\bwithin\b.*\b(hour|minute|min|hr)\b",
    r"\brapid\b",
]


def _count_signals(text: str, patterns: list[str]) -> int:
    text_lower = text.lower()
    return sum(1 for p in patterns if re.search(p, text_lower, re.IGNORECASE))


# ── Router ────────────────────────────────────────────────────────────────────

def classify_query(query: str) -> RoutingDecision:
    """
    Deterministically classify a user query into one of four routing paths.
    Returns a RoutingDecision describing which tools should be invoked.
    """
    t = _count_signals(query, _TRANSACTION_SIGNALS)
    p = _count_signals(query, _POLICY_SIGNALS)
    c = _count_signals(query, _PATTERN_SIGNALS)

    # Path C takes priority if pattern signals dominate (velocity scenario)
    if c >= 2 and c >= t:
        return RoutingDecision(
            path=QueryPath.PATTERN,
            use_ml=True,
            use_rag=True,
            use_risk_score=True,
            reason=(
                f"Pattern/velocity signals ({c}) detected. "
                "calculate_risk_score → predict_fraud_risk → retrieve_policy."
            ),
        )

    # Path A if transaction signals dominate
    if t >= 2 and t > p:
        return RoutingDecision(
            path=QueryPath.TRANSACTION,
            use_ml=True,
            use_rag=True,    # may be needed if risk is high — agent decides
            use_risk_score=False,
            reason=(
                f"Transaction signals ({t}) detected. "
                "predict_fraud_risk; retrieve_policy if risk ≥ 0.70."
            ),
        )

    # Path B if policy signals dominate
    if p >= 1 and p >= t and p >= c:
        return RoutingDecision(
            path=QueryPath.POLICY,
            use_ml=False,
            use_rag=True,
            use_risk_score=False,
            reason=(
                f"Policy/procedure signals ({p}) detected. retrieve_policy only."
            ),
        )

    # Path D — ambiguous
    return RoutingDecision(
        path=QueryPath.AMBIGUOUS,
        use_ml=False,
        use_rag=True,
        use_risk_score=False,
        reason=(
            f"No dominant signal (transaction={t}, policy={p}, pattern={c}). "
            "Defaulting to retrieve_policy."
        ),
    )


# ── Risk-level gating ─────────────────────────────────────────────────────────

def should_escalate_to_policy(ml_result: dict) -> bool:
    """Return True if the ML score is high enough to warrant a policy retrieval."""
    return ml_result.get("fraud_probability", 0.0) >= 0.70


def should_escalate_to_ml(risk_score_result: dict) -> bool:
    """Return True if composite score is high enough to warrant ML prediction."""
    return risk_score_result.get("composite_score", 0.0) >= 7.0


# ── Decision flow diagram (text) ───────────────────────────────────────────────

DECISION_DIAGRAM = """
┌─────────────────────────────────────────────────────────────────┐
│          FINANCIAL FRAUD DETECTION AGENT — DECISION FLOW         │
└─────────────────────────────────────────────────────────────────┘

User Query
    │
    ▼
┌──────────────────────────┐
│   Query Classifier       │  (deterministic keyword analysis + LLM reasoning)
│   classify_query(q)      │
└──────────────────────────┘
    │
    ├──[Pattern/Velocity signals ≥ 2]──────────────────────────────────┐
    │                                                                   ▼
    │                                              ┌─────────────────────────────┐
    │                                              │ calculate_risk_score()      │
    │                                              │ (amount, frequency,         │
    │                                              │  time, device, location)    │
    │                                              └─────────────────────────────┘
    │                                                   │
    │                                    ┌──[score ≥ 7.0]──────────────┐
    │                                    ▼                              ▼
    │                         ┌─────────────────┐         Monitor / Flag for review
    │                         │predict_fraud_risk│
    │                         └─────────────────┘
    │                                    │
    │                         ┌──[prob ≥ 0.70]──┐
    │                         ▼                  ▼
    │                  retrieve_policy()    [Low/Medium]
    │                                       Report + Monitor
    │
    ├──[Transaction signals ≥ 2]───────────────────────────────────────┐
    │                                                                   ▼
    │                                              ┌─────────────────────────────┐
    │                                              │   predict_fraud_risk()      │
    │                                              │   (Amount, Time, V1-V28)    │
    │                                              └─────────────────────────────┘
    │                                                        │
    │                                           ┌──[prob ≥ 0.70]──────┐
    │                                           ▼                      ▼
    │                                   retrieve_policy()         [Low/Medium]
    │                                   (escalation steps)        Log & Monitor
    │
    ├──[Policy signals ≥ 1]────────────────────────────────────────────┐
    │                                                                   ▼
    │                                              ┌─────────────────────────────┐
    │                                              │     retrieve_policy()        │
    │                                              │  (RAG over compliance docs)  │
    │                                              └─────────────────────────────┘
    │
    └──[Ambiguous / unclear]────────────────────────────────────────────┐
                                                                        ▼
                                                       retrieve_policy() [safe default]

─────────────────────────────────────────────────────────────────────────
Final step (all paths):
    LLM synthesizes tool outputs → grounded, explainable recommendation
    Human analyst reviews → takes final action
─────────────────────────────────────────────────────────────────────────
"""


if __name__ == "__main__":
    print(DECISION_DIAGRAM)

    test_queries = [
        "A transaction of $4,500 was made from a new device at 2:30 AM. Is this likely fraud?",
        "What is the bank's policy when a high-risk transaction is detected on a corporate account?",
        "Customer Ahmed made 14 transactions in 20 minutes totalling $6,200. What action should be taken?",
        "Can you help with this account?",
    ]
    print("\n── Query Classification Tests ──────────────────────────\n")
    for q in test_queries:
        decision = classify_query(q)
        print(f"Query: {q[:75]}...")
        print(f"  Path: {decision.path.name} ({decision.path.value})")
        print(f"  ML={decision.use_ml}  RAG={decision.use_rag}  RiskScore={decision.use_risk_score}")
        print(f"  Reason: {decision.reason}\n")
