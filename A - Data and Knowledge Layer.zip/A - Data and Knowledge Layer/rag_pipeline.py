"""
Part A – Data & Knowledge Layer
RAG pipeline: document ingestion, chunking, embedding, and retrieval
using Azure AI Search (vector search).

Run this script once to build the index, then call retrieve_policy() at query time.
"""

import os
import re
import json
import glob
from pathlib import Path

from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SearchField, SearchFieldDataType,
    SimpleField, SearchableField, VectorSearch,
    HnswAlgorithmConfiguration, VectorSearchProfile,
    SearchField as VectorField,
)
from azure.search.documents.models import VectorizedQuery
from azure.core.credentials import AzureKeyCredential
from openai import AzureOpenAI

import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "E - System Integration"))
from config import (
    AZURE_SEARCH_ENDPOINT, AZURE_SEARCH_KEY, AZURE_SEARCH_INDEX,
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION,
    AZURE_EMBED_ENDPOINT, AZURE_EMBED_API_VERSION,
    AZURE_EMBED_DEPLOYMENT, EMBED_DIMENSIONS, CHUNK_SIZE, CHUNK_OVERLAP, TOP_K_RESULTS,
)

# ── Clients ──────────────────────────────────────────────────────────────────

credential = AzureKeyCredential(AZURE_SEARCH_KEY)
index_client = SearchIndexClient(endpoint=AZURE_SEARCH_ENDPOINT, credential=credential)
search_client = SearchClient(
    endpoint=AZURE_SEARCH_ENDPOINT,
    index_name=AZURE_SEARCH_INDEX,
    credential=credential,
)
openai_client = AzureOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
)
embed_client = AzureOpenAI(
    azure_endpoint=AZURE_EMBED_ENDPOINT,
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_EMBED_API_VERSION,
)


# ── Index schema ─────────────────────────────────────────────────────────────

def create_search_index():
    """Create the Azure AI Search index with vector fields."""
    fields = [
        SimpleField(name="id",           type=SearchFieldDataType.String, key=True),
        SearchableField(name="content",  type=SearchFieldDataType.String),
        SimpleField(name="source",       type=SearchFieldDataType.String, filterable=True),
        SimpleField(name="chunk_index",  type=SearchFieldDataType.Int32),
        SearchField(
            name="embedding",
            type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
            searchable=True,
            vector_search_dimensions=EMBED_DIMENSIONS,
            vector_search_profile_name="hnsw-profile",
        ),
    ]
    vector_search = VectorSearch(
        algorithms=[HnswAlgorithmConfiguration(name="hnsw-algo")],
        profiles=[VectorSearchProfile(name="hnsw-profile", algorithm_configuration_name="hnsw-algo")],
    )
    index = SearchIndex(name=AZURE_SEARCH_INDEX, fields=fields, vector_search=vector_search)
    index_client.create_or_update_index(index)
    print(f"Index '{AZURE_SEARCH_INDEX}' created/updated.")


# ── Chunking ─────────────────────────────────────────────────────────────────

def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list[str]:
    """
    Split text into overlapping word-based chunks.
    chunk_size and overlap are measured in words (proxy for tokens).
    """
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = start + chunk_size
        chunks.append(" ".join(words[start:end]))
        start += chunk_size - overlap
    return chunks


# ── Embedding ─────────────────────────────────────────────────────────────────

def embed(texts: list[str]) -> list[list[float]]:
    """Embed a list of strings using Azure OpenAI embeddings."""
    response = embed_client.embeddings.create(
        input=texts,
        model=AZURE_EMBED_DEPLOYMENT,
    )
    return [item.embedding for item in response.data]


# ── Ingestion ─────────────────────────────────────────────────────────────────

def ingest_documents(docs_folder: str):
    """
    Read all .md and .txt files from docs_folder, chunk them,
    embed each chunk, and upload to Azure AI Search.
    """
    create_search_index()

    doc_paths = glob.glob(os.path.join(docs_folder, "*.md")) + \
                glob.glob(os.path.join(docs_folder, "*.txt")) + \
                glob.glob(os.path.join(docs_folder, "*.pdf"))

    if not doc_paths:
        print("No documents found in", docs_folder)
        return

    all_documents = []
    for path in doc_paths:
        source_name = Path(path).stem
        print(f"Processing: {source_name}")

        if path.endswith(".pdf"):
            # Basic PDF text extraction — install pypdf2 if needed
            try:
                import PyPDF2
                with open(path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    text = "\n".join(page.extract_text() or "" for page in reader.pages)
            except ImportError:
                print(f"  Skipping {path} — install PyPDF2 for PDF support.")
                continue
        else:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()

        # Remove markdown symbols to get cleaner text for embedding
        text_clean = re.sub(r"[#*`|_\-]+", " ", text)

        chunks = chunk_text(text_clean)
        embeddings = embed(chunks)

        for i, (chunk, vector) in enumerate(zip(chunks, embeddings)):
            all_documents.append({
                "id":          f"{source_name}-{i}",
                "content":     chunk,
                "source":      source_name,
                "chunk_index": i,
                "embedding":   vector,
            })

    # Upload in batches of 100
    batch_size = 100
    for i in range(0, len(all_documents), batch_size):
        batch = all_documents[i : i + batch_size]
        search_client.upload_documents(documents=batch)
        print(f"  Uploaded chunks {i} – {i + len(batch) - 1}")

    print(f"\nIngestion complete. Total chunks: {len(all_documents)}")


# ── Retrieval ─────────────────────────────────────────────────────────────────

def retrieve_policy(query: str, top_k: int = TOP_K_RESULTS) -> list[dict]:
    """
    Retrieve the most relevant policy chunks for a given query.
    Uses pure vector (semantic) search.

    Returns a list of dicts with keys: source, content, score.
    """
    query_vector = embed([query])[0]
    vector_query = VectorizedQuery(
        vector=query_vector,
        k_nearest_neighbors=top_k,
        fields="embedding",
    )
    results = search_client.search(
        search_text=None,
        vector_queries=[vector_query],
        select=["source", "content"],
        top=top_k,
    )
    retrieved = []
    for r in results:
        retrieved.append({
            "source":  r["source"],
            "content": r["content"],
            "score":   r["@search.score"],
        })
    return retrieved


def format_retrieved_context(results: list[dict]) -> str:
    """Format retrieved chunks into a single context string for the LLM."""
    if not results:
        return "No relevant policy documents found."
    parts = []
    for i, r in enumerate(results, 1):
        parts.append(f"[Source {i}: {r['source']}]\n{r['content']}")
    return "\n\n---\n\n".join(parts)


# ── CLI entry point ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--ingest", action="store_true", help="Ingest documents into Azure AI Search")
    parser.add_argument("--query",  type=str, help="Test retrieval with a query")
    parser.add_argument(
        "--docs-folder",
        default=str(Path(__file__).parent / "RAG Documents"),
        help="Path to folder containing policy documents",
    )
    args = parser.parse_args()

    if args.ingest:
        ingest_documents(args.docs_folder)

    if args.query:
        results = retrieve_policy(args.query)
        print("\nRetrieved policy chunks:")
        for r in results:
            print(f"\n[{r['source']}] (score={r['score']:.4f})")
            print(r["content"][:300], "...")
