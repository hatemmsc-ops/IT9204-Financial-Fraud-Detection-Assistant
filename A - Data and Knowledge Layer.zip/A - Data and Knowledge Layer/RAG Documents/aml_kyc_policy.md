# Anti-Money Laundering (AML) and Know Your Customer (KYC) Policy
**Document Type:** Regulatory Compliance Policy  
**Version:** 2.1 | **Effective Date:** March 2025  
**Regulatory Basis:** Central Bank of Bahrain (CBB) Module FC – Financial Crime  

---

## 1. Overview

This policy establishes the framework for preventing money laundering, terrorist financing, and other financial crimes. All staff must adhere to these requirements. Non-compliance is subject to disciplinary action and may result in regulatory penalties.

---

## 2. Know Your Customer (KYC) Requirements

### 2.1 Customer Due Diligence (CDD)
All new customers must be verified before account opening:
- **Identity verification:** Government-issued photo ID (CPR, Passport).
- **Address verification:** Utility bill or bank statement dated within 3 months.
- **Source of funds:** Declaration form for accounts expecting transactions above BD 5,000/month.

### 2.2 Enhanced Due Diligence (EDD)
EDD is mandatory for:
- Politically Exposed Persons (PEPs).
- Customers from high-risk jurisdictions (as listed by FATF).
- Customers with complex ownership structures.
- Any customer whose transactions trigger repeated fraud alerts.

EDD includes senior management approval, more frequent transaction monitoring (monthly), and documented review of source of wealth.

### 2.3 Ongoing Monitoring
Customer profiles must be reviewed:
- **Annually** for standard-risk customers.
- **Semi-annually** for medium-risk customers.
- **Quarterly** for high-risk customers and PEPs.

---

## 3. Transaction Monitoring

### 3.1 Monitoring Triggers
The transaction monitoring system automatically flags:
- Cash transactions above BD 6,000.
- International wire transfers above $10,000 to or from high-risk countries.
- Multiple transactions just below reporting thresholds (structuring).
- Sudden large deposits inconsistent with the customer's known income profile.
- Transactions at unusual hours (midnight to 5:00 AM local time) above BD 1,000.

### 3.2 Alert Disposition
When an alert is generated:
1. The AML analyst reviews the alert within 24 hours.
2. If the alert is explainable (e.g., salary deposit), it is closed with documentation.
3. If the alert cannot be explained, the analyst must escalate to the MLRO (Money Laundering Reporting Officer).
4. The MLRO determines whether a SAR should be filed.

---

## 4. High-Risk Indicators

The following behaviors are recognized typologies for money laundering:
- **Structuring (Smurfing):** Multiple transactions just below BD 6,000 within a short period.
- **Rapid movement:** Funds deposited and immediately transferred out to a third party.
- **Round-number transactions:** Large transfers in round amounts without a clear business purpose.
- **Geographic inconsistency:** Transactions initiated from a country where the customer has no known connections.
- **Device inconsistency:** A customer suddenly using a new, unregistered device for large transactions.

---

## 5. Sanctions Screening

All customers and transactions must be screened against:
- UN Security Council Sanctions List.
- OFAC SDN List (USA).
- HM Treasury Consolidated List (UK).
- CBB Blacklist.

Any match must be immediately escalated to Compliance and the transaction frozen pending review. Do not notify the customer of a sanctions hit.

---

## 6. Record Keeping

All KYC documents, transaction records, and AML investigation files must be retained for a minimum of **7 years** in accordance with CBB requirements. Records must be retrievable within 48 hours upon regulatory request.

---

## 7. Training

All customer-facing and compliance staff must complete AML/KYC training:
- **Annually:** Refresher course (minimum 4 hours).
- **On joining:** Induction training within 30 days.
- Training completion must be logged in the Learning Management System (LMS).

---

## 8. Penalties for Non-Compliance

Failure to comply with AML/KYC requirements may result in:
- Regulatory fines from the CBB (up to BD 10,000 per violation).
- Criminal prosecution under the Bahraini Anti-Money Laundering Law (Law No. 4 of 2001 and its amendments).
- Personal liability for the MLRO and senior management.
