# Bank Fraud Response and Escalation Procedures
**Document Type:** Internal Policy  
**Version:** 3.2 | **Effective Date:** January 2025  
**Owner:** Risk and Compliance Division

---

## 1. Purpose and Scope

This document defines the procedures that fraud analysts and risk officers must follow when a fraudulent or suspicious transaction is detected. It applies to all retail banking, corporate banking, and digital banking channels.

---

## 2. Fraud Severity Classification

| Tier | Probability Score | Transaction Value | Action Required |
|------|-------------------|-------------------|-----------------|
| **Tier 1 – Low Risk** | < 0.40 | Any | Log and monitor. No immediate intervention. |
| **Tier 2 – Medium Risk** | 0.40 – 0.69 | Any | Flag for analyst review within 4 hours. Notify account holder via SMS. |
| **Tier 3 – High Risk** | 0.70 – 0.89 | Any | Temporarily freeze transaction. Analyst must review within 1 hour. Notify customer. |
| **Tier 4 – Critical** | ≥ 0.90 OR > $10,000 with score ≥ 0.70 | > $10,000 | Immediately block transaction. Escalate to Senior Risk Officer. File Suspicious Activity Report (SAR) within 24 hours. |

---

## 3. Immediate Response Steps (High-Risk Transactions)

1. **Freeze the transaction** – Do not process until verified.
2. **Notify the customer** – Send automated SMS and email within 5 minutes of detection.
3. **Record the incident** – Log in the Fraud Case Management System (FCMS) with timestamp, transaction ID, amount, channel, and detected risk score.
4. **Analyst assignment** – The system auto-assigns the case to the next available analyst. Tier 4 cases go directly to a Senior Risk Officer.
5. **Customer verification** – Call the registered phone number. If the customer confirms the transaction is unauthorized, proceed to card/account freeze.
6. **Investigation** – Analyst reviews transaction history, device fingerprint, IP geolocation, and prior alerts.

---

## 4. Corporate Account Procedures

For corporate or business accounts with high-risk transactions:
- The Relationship Manager (RM) must be notified within 30 minutes.
- If the RM is unavailable, escalate directly to the Corporate Banking Risk Desk.
- All high-risk transactions on corporate accounts exceeding BD 5,000 require dual authorization from two senior analysts before releasing funds.
- A mandatory post-incident review must be completed within 72 hours.

---

## 5. Rapid Transaction Pattern Alert

When a customer executes more than **10 transactions within 30 minutes** or cumulative value exceeds **$5,000 in 60 minutes**:
- The system triggers a velocity alert.
- The analyst must calculate a composite risk score before deciding on action.
- If the composite score is ≥ 7.0 (out of 10), freeze the account and escalate.

---

## 6. Suspicious Activity Report (SAR) Filing

A SAR must be filed when:
- The ML fraud probability score is ≥ 0.85.
- The transaction involves structuring (multiple transactions just below reporting thresholds).
- The customer's behavior matches known money laundering typologies.
- The analyst has reasonable grounds to suspect fraud, even without a high ML score.

SAR filings must be submitted to the Financial Intelligence Unit (FIU) through the secure reporting portal within **24 hours** of detection.

---

## 7. Post-Incident Review

All Tier 3 and Tier 4 incidents require:
- A written incident report submitted within 5 business days.
- Root cause analysis identifying how the fraud occurred.
- Recommendations for control improvements.
- Review by the Head of Compliance and the CISO for Tier 4 incidents.

---

## 8. Communication Guidelines

- **Never** disclose investigation details to the customer beyond confirming the account is under review.
- All internal communications about active fraud cases must use encrypted channels.
- Media inquiries must be redirected to the Communications Department immediately.
