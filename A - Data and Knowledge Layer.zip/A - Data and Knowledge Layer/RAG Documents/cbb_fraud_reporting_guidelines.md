# Central Bank of Bahrain – Fraud Reporting Guidelines
**Regulatory Reference:** CBB Rulebook Volume 1, Module FC (Financial Crime)  
**Document Type:** Regulatory Compliance Summary  
**Jurisdiction:** Kingdom of Bahrain  

---

## 1. Legal Framework

Financial institutions licensed by the Central Bank of Bahrain (CBB) are required to comply with:
- **CBB Law (Decree Law No. 64 of 2006)** – Establishes the CBB's supervisory authority.
- **Anti-Money Laundering Law (Law No. 4 of 2001, as amended)** – Criminalizes money laundering and requires reporting of suspicious transactions.
- **CBB Rulebook, Module FC** – Specifies detailed financial crime compliance obligations.
- **Resolution No. 23 of 2017** – Establishes the Financial Intelligence Unit (FIU) reporting framework.

---

## 2. Mandatory Fraud Reporting Obligations

### 2.1 Suspicious Transaction Reports (STRs)
Licensed institutions must file a Suspicious Transaction Report (STR) with the FIU when:
- A transaction is suspected to involve proceeds of crime.
- A customer's activity is inconsistent with their known profile without a reasonable explanation.
- A transaction matches recognized fraud or money laundering typologies.

**Filing deadline:** Within **3 business days** of the analyst forming suspicion. Filing must not be delayed pending investigation completion.

### 2.2 Currency Transaction Reports (CTRs)
A Currency Transaction Report is required for:
- Cash transactions exceeding **BD 6,000** in a single transaction.
- Multiple cash transactions by the same customer on the same day totaling BD 6,000 or more (structuring alert).

**Filing deadline:** Within **5 business days** of the transaction.

### 2.3 Cross-Border Wire Transfer Reports
All international wire transfers **exceeding $10,000 (or equivalent)** must be reported to the CBB's Financial Transactions Reporting Unit (FTRU) within **5 business days**.

---

## 3. Tipping-Off Prohibition

Under Article 10 of Law No. 4 of 2001:
- It is a criminal offense to inform a customer or any third party that an STR has been filed or that an investigation is underway.
- Staff who disclose this information face imprisonment of up to **1 year** and/or a fine of up to **BD 10,000**.
- All internal communications about active STR filings must be restricted to need-to-know personnel.

---

## 4. Cybercrime and E-Fraud Reporting

The CBB requires separate reporting for electronic fraud incidents:
- **E-fraud incidents** (unauthorized access to accounts, phishing, card-not-present fraud) must be reported to the CBB's IT Supervision Directorate within **24 hours** of detection.
- A detailed incident report must be submitted within **5 business days**.
- Recurring e-fraud patterns must be reported in the quarterly Financial Crime Return (FCR).

---

## 5. Internal Controls Required by the CBB

All licensed banks must maintain:
- A dedicated **Money Laundering Reporting Officer (MLRO)** who has direct access to senior management.
- A **transaction monitoring system** capable of real-time detection.
- An escalation matrix defining who can authorize account freezes at each transaction value tier.
- Annual independent audit of the AML/CFT compliance program.

---

## 6. Cooperation with Investigations

When law enforcement or the CBB requests information related to a fraud investigation:
- Respond within **48 hours** to the requesting authority.
- Provide complete transaction histories, customer records, and all investigation files.
- Do not destroy any potentially relevant records once a formal inquiry has been received.

---

## 7. Sanctions for Non-Compliance

The CBB may impose the following sanctions for failure to comply:
- Written warnings and required remediation plans.
- Financial penalties up to **BD 10,000 per violation**.
- Suspension or revocation of the banking license for repeated or serious breaches.
- Referral to the Public Prosecution for criminal violations.

---

## 8. Interaction with Fraud Detection Systems

When an AI-based fraud detection system recommends action:
- The **human analyst remains responsible** for all decisions. The AI provides decision support only.
- If the system recommends filing an STR, the MLRO must review and authorize the filing.
- Automated transaction blocks triggered by the system must be reviewed and confirmed by a qualified analyst within **1 hour** for Tier 3 and Tier 4 cases.
- All AI-generated risk scores and recommendations must be logged alongside the final human decision for audit purposes.
