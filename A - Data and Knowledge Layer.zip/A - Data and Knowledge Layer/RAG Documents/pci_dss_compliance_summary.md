# PCI-DSS Compliance Summary for Fraud Detection Operations
**Standard:** PCI DSS v4.0  
**Document Type:** Internal Compliance Reference  
**Audience:** Fraud Analysts, Security Officers, IT Teams  

---

## 1. Overview of PCI DSS

The Payment Card Industry Data Security Standard (PCI DSS) is a global security standard that protects cardholder data. Any organization that stores, processes, or transmits payment card data must comply. Non-compliance can result in fines from card networks (Visa, Mastercard) and loss of the ability to process card payments.

---

## 2. Key Requirements Relevant to Fraud Detection

### Requirement 3 – Protect Stored Account Data
- Cardholder data (Primary Account Number, cardholder name, expiry date) must **never be stored** after authorization unless there is a legitimate business need.
- If stored, PAN must be masked so that only the last four digits are readable.
- Encryption of stored cardholder data is mandatory using strong cryptography (AES-256 or equivalent).

### Requirement 6 – Develop and Maintain Secure Systems
- All fraud detection systems and APIs must be protected against known vulnerabilities.
- Security patches must be applied within **one month** of release for critical patches.
- Fraud detection model endpoints must use HTTPS (TLS 1.2 or higher). No unencrypted API calls.

### Requirement 10 – Log and Monitor All Access to System Components
- All access to cardholder data and fraud detection systems must be logged.
- Logs must capture: user ID, event type, date/time, success/failure, originating device.
- Logs must be reviewed **daily** for anomalies.
- Logs must be retained for at least **12 months**, with 3 months immediately available for analysis.

### Requirement 11 – Test Security of Systems and Networks
- Fraud detection systems must undergo **penetration testing at least annually**.
- Vulnerability scans must be conducted quarterly.

### Requirement 12 – Support Information Security with Organizational Policies
- A formal security policy must be documented and reviewed annually.
- All staff with access to cardholder data must complete security awareness training annually.

---

## 3. Fraud-Specific Compliance Controls

### 3.1 Real-Time Monitoring Obligation
Banks processing card transactions must maintain **real-time fraud monitoring** capable of:
- Detecting unusual velocity (multiple transactions in a short time window).
- Detecting geographic impossibility (e.g., transaction in two countries within 1 hour).
- Detecting unusual merchant category codes for a given cardholder profile.

### 3.2 Data Minimization in ML Models
When building ML fraud detection models:
- Do not use raw PANs as model features.
- PCA-transformed features (as in the Kaggle creditcard dataset) are acceptable and privacy-preserving.
- Model training logs must not contain cardholder identifiable data.

### 3.3 Incident Response for Card Data Breaches
If a fraud incident involves suspected exposure of cardholder data:
1. Immediately contain the breach (isolate affected systems).
2. Notify Visa/Mastercard within **24 hours**.
3. Engage a PCI Forensic Investigator (PFI) within 72 hours.
4. Submit a final incident report within **10 business days**.

---

## 4. Consequences of Non-Compliance

| Violation Level | Fine Range | Additional Penalty |
|-----------------|------------|--------------------|
| Minor (first offense) | $5,000 – $10,000/month | Mandatory audit |
| Repeat/Moderate | $10,000 – $50,000/month | Escalation to card brands |
| Severe breach | Up to $500,000 per incident | Loss of card processing rights |

---

## 5. Relationship to Fraud Detection Workflow

When the fraud detection agent retrieves PCI-DSS policy, the relevant controls are:
- Requirement 10 (logging) confirms that all agent decisions must be logged with timestamps and reasoning.
- Requirement 3 (data protection) means the agent must never expose full PAN in its responses.
- Requirement 6 (secure systems) means the ML endpoint must use encrypted HTTPS communication.
